import AbstractStatefulView from '../framework/view/abstract-stateful-view.js';
import { TIME_FORMATS } from '../const.js';
import { formatDate } from '../utils.js';
import flatpickr from 'flatpickr';
import he from 'he';

function buildEditFormTemplate(point) {
  const {
    dateFrom,
    dateTo,
    basePrice,
    type,
    offers,
    destinationName,
    destinationPictures,
    description,
    isDisabled,
    isSaving,
    isDeleting
  } = point;

  const saveDisabled = !basePrice || !dateFrom || !dateTo || !destinationName;
  const offersMarkup = offers.map((offer) => `
    <div class="event__offer-selector">
      <input class="event__offer-checkbox visually-hidden"
        id="event-offer-${offer.title}-${offer.id}" type="checkbox"
        name="event-offer-${offer.title}" ${offer.isSelected ? 'checked' : ''}>
      <label class="event__offer-label" for="event-offer-${offer.title}-${offer.id}">
        <span class="event__offer-title">${offer.title}</span>
        &plus;&euro;&nbsp;<span class="event__offer-price">${offer.price}</span>
      </label>
    </div>`).join('');

  const picturesMarkup = destinationPictures.map((pic) =>
    `<img class="event__photo" src="${pic.src}" alt="${pic.description}">`
  ).join('');

  return `<li class="trip-events__item">
    <form class="event event--edit" action="#" method="post">
      <header class="event__header">
        <div class="event__type-wrapper">
          <label class="event__type  event__type-btn" for="event-type-toggle-1">
            <span class="visually-hidden">Choose event type</span>
            <img class="event__type-icon" width="17" height="17" src="img/icons/${type}.png" alt="Event type icon">
          </label>
          <input class="event__type-toggle visually-hidden" id="event-type-toggle-1" type="checkbox">
        </div>

        <div class="event__field-group event__field-group--destination">
          <label class="event__label event__type-output" for="event-destination-1">${type}</label>
          <input class="event__input event__input--destination" id="event-destination-1"
            type="text" name="event-destination" value="${destinationName || ''}" list="destination-list-1">
        </div>

        <div class="event__field-group event__field-group--time">
          <label class="visually-hidden" for="event-start-time-1">From</label>
          <input class="event__input event__input--time" id="event-start-time-1"
            type="text" name="event-start-time"
            value="${dateFrom ? formatDate(dateFrom, TIME_FORMATS.FULL_DATE) : ''}">
          &mdash;
          <label class="visually-hidden" for="event-end-time-1">To</label>
          <input class="event__input event__input--time" id="event-end-time-1"
            type="text" name="event-end-time"
            value="${dateTo ? formatDate(dateTo, TIME_FORMATS.FULL_DATE) : ''}">
        </div>

        <div class="event__field-group event__field-group--price">
          <label class="event__label" for="event-price-1">
            <span class="visually-hidden">Price</span>&euro;
          </label>
          <input class="event__input event__input--price" id="event-price-1"
            type="text" name="event-price"
            value="${he.encode(String(basePrice))}" ${isDisabled ? 'disabled' : ''}>
        </div>

        <button class="event__save-btn btn btn--blue" type="submit"
          ${saveDisabled || isDisabled ? 'disabled' : ''}>
          ${isSaving ? 'Saving...' : 'Save'}
        </button>
        <button class="event__reset-btn" type="reset">${isDeleting ? 'Deleting...' : 'Delete'}</button>
      </header>

      <section class="event__details">
        ${offersMarkup ? `
          <section class="event__section event__section--offers">
            <h3 class="event__section-title">Offers</h3>
            <div class="event__available-offers">${offersMarkup}</div>
          </section>` : ''}

        ${description ? `
          <section class="event__section event__section--destination">
            <h3 class="event__section-title">Destination</h3>
            <p class="event__destination-description">${description}</p>
            <div class="event__photos-container">
              <div class="event__photos-tape">${picturesMarkup}</div>
            </div>
          </section>` : ''}
      </section>
    </form>
  </li>`;
}

export default class FormEditView extends AbstractStatefulView {
  #datepickerFrom = null;
  #datepickerTo = null;
  #onSubmit = null;
  #onCancel = null;
  #onDelete = null;

  constructor({ point, offer, destination, onRollupClick, onFormSubmit, onDeleteClick }) {
    super();
    this._setState({
      ...point,
      offers: offer.offers,
      destinationName: destination.name,
      destinationPictures: destination.pictures,
      description: destination.description,
      isDisabled: false,
      isSaving: false,
      isDeleting: false,
    });

    this.#onSubmit = onFormSubmit;
    this.#onCancel = onRollupClick;
    this.#onDelete = onDeleteClick;

    this._restoreHandlers();
  }

  get template() {
    return buildEditFormTemplate(this._state);
  }

  _restoreHandlers() {
    const form = this.element.querySelector('.event');
    form.addEventListener('submit', this.#handleSubmit);
    form.querySelector('.event__rollup-btn')?.addEventListener('click', this.#handleRollupClick);
    form.querySelector('.event__reset-btn')?.addEventListener('click', this.#handleDeleteClick);

    this.#initDatepickers();
  }

  updateElement(newState) {
    super.updateElement(newState);
  }

  shake(callback) {
    this.element.style.animation = 'shake 0.6s';
    this.element.style.transformOrigin = 'center';

    setTimeout(() => {
      this.element.style.animation = '';
      if (callback) {
        callback();
      }
    }, 600);
  }

  reset() {
    this.updateElement(this._state);
  }

  #handleSubmit = (evt) => {
    evt.preventDefault();
    this.#onSubmit(FormEditView.toPoint(this._state));
  };

  #handleDeleteClick = (evt) => {
    evt.preventDefault();
    this.#onDelete(FormEditView.toPoint(this._state));
  };

  #handleRollupClick = (evt) => {
    evt.preventDefault();
    this.#onCancel();
  };

  #onStartDateChange = ([date]) => {
    this.updateElement({ dateFrom: date });
  };

  #onEndDateChange = ([date]) => {
    this.updateElement({ dateTo: date });
  };

  #initDatepickers() {
    this.#datepickerFrom = flatpickr(
      this.element.querySelector('#event-start-time-1'),
      {
        dateFormat: 'd/m/y H:i',
        enableTime: true,
        time24hr: true,
        defaultDate: this._state.dateFrom,
        onChange: this.#onStartDateChange,
        maxDate: this._state.dateTo,
      }
    );

    this.#datepickerTo = flatpickr(
      this.element.querySelector('#event-end-time-1'),
      {
        dateFormat: 'd/m/y H:i',
        enableTime: true,
        time24hr: true,
        defaultDate: this._state.dateTo,
        onChange: this.#onEndDateChange,
        minDate: this._state.dateFrom,
      }
    );
  }

  static toPoint(state) {
    const cleaned = { ...state };
    delete cleaned.destinationName;
    delete cleaned.destinationPictures;
    delete cleaned.description;
    return cleaned;
  }
}
