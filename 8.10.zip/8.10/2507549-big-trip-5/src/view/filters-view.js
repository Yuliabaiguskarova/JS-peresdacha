import AbstractView from '../framework/view/abstract-view.js';

function createFilterItem({ type, checked }) {
  return `
    <div class="trip-filters__filter">
      <input id="filter-${type}" class="trip-filters__filter-input visually-hidden" type="radio"
        name="trip-filter" value="${type}" ${checked ? 'checked' : ''}>
      <label class="trip-filters__filter-label" for="filter-${type}">${type}</label>
    </div>`;
}

function buildFilterTemplate(filters) {
  const filtersMarkup = filters
    .map((filter) => createFilterItem({ type: filter.type, checked: filter.isChecked }))
    .join('');

  return `
    <form class="trip-filters" action="#" method="get">
      ${filtersMarkup}
      <button class="visually-hidden" type="submit">Accept filter</button>
    </form>`;
}

export default class FiltersView extends AbstractView {
  #filters = null;
  #onFilterChange = null;

  constructor({ filters, onFilterTypeChange }) {
    super();
    this.#filters = filters.map((filter) => ({
      ...filter,
      isChecked: filter.type === 'everything',
    }));
    this.#onFilterChange = onFilterTypeChange;

    this.element.addEventListener('change', this.#handleFilterChange);
  }

  get template() {
    return buildFilterTemplate(this.#filters);
  }

  #handleFilterChange = (evt) => {
    evt.preventDefault();
    this.#onFilterChange(evt.target.value);
  };
}
