import AbstractView from '../framework/view/abstract-view.js';
import { SORT_TYPES } from '../const.js';

function buildSortOption(type, currentType) {
  return `
    <div class="trip-sort__item trip-sort__item--${type}">
      <input id="sort-${type}" class="trip-sort__input visually-hidden" type="radio" name="trip-sort"
        value="sort-${type}" ${type === currentType ? 'checked' : ''}>
      <label class="trip-sort__btn" for="sort-${type}">${type}</label>
    </div>`;
}

function generateSortTemplate(activeSort) {
  const options = SORT_TYPES.map((type) => buildSortOption(type, activeSort)).join('');
  return `<form class="trip-events__trip-sort trip-sort" action="#" method="get">${options}</form>`;
}

export default class SortView extends AbstractView {
  #selectedSort = null;
  #onSortChange = null;

  constructor({ sortType, onSortTypeChange }) {
    super();
    this.#selectedSort = sortType;
    this.#onSortChange = onSortTypeChange;

    this.element.addEventListener('change', this.#handleSortChange);
  }

  get template() {
    return generateSortTemplate(this.#selectedSort);
  }

  #handleSortChange = (evt) => {
    evt.preventDefault();
    const selected = evt.target.value.replace('sort-', '');
    this.#onSortChange(selected);
  };
}
