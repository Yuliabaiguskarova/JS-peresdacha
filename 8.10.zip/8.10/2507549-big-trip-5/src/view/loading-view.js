import AbstractView from '../framework/view/abstract-view.js';

function buildLoadingTemplate() {
  return '<p class="trip-events__msg">Loading...</p>';
}

export default class LoaderView extends AbstractView {
  get template() {
    return buildLoadingTemplate();
  }
}
