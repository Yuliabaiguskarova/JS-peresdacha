import AbstractStatefulView from '../framework/view/abstract-stateful-view.js';
import { TIME_FORMATS, EVENT_TYPES } from '../const.js';
import { formatDate } from '../utils.js';
import flatpickr from 'flatpickr';
import he from 'he';

function buildCreationTemplate(point) {
  const {
    dateFrom,
    dateTo,
    basePrice,
    type,
    offers,
    destinationName,
    destinationPictures,
    description
  } = point;

  const eventTypeOptions = EVENT_TYPES.map((event) => `
    <div class="event__type-item">
      <input id="event-type-${event}-1" class="event__type-input visually-hidden" type="radio" name="event-type" value="${event}" ${event === type ? 'checked' : ''}>
      <label class="event__type-label event__type-label--${event}" for="event-type-${event}-1">${event.charAt(0).toUpperCase() + event.slice(1)}</label>
    </div>`).join('');

  const offerMarkup = offers.map((offer) => {
    const isChecked = offers.includes(offer.id) ? 'checked' : '';
    const name = offer.title.toLowerCase().split(' ').join('-');
    return `
      <div class="event__offer-selector">
        <input class="event__offer-checkbox visually-hidden" id="event-offer-${name}-${offer.id}" type="checkbox" name="event-offer-${name}" ${isChecked}>
        <label class="event__offer-label" for="event-offer-${name}-${offer.id}">
          <span class="event__offer-title">${offer.title}</span>
          &plus;&euro;&nbsp;<span class="event__offer-price">${offer.price}</span>
        </label>
      </div>`;
  }).join('');

  const picturesMarkup = destinationPictures.map((pic) => `
    <img class="event__photo" src="${pic.src}" alt="${pic.description}">
  `).join('');

  return `<li class="trip-events__item">
    <form class="event event--edit" action="#" method="post">
      <header class="event__header">
        <div class="event__type-wrapper">
          <label class="event__type event__type-btn" for="event-type-toggle-1">
            <span class="visually-hidden">Choose event type</span>
            <img class="event__type-icon" width="17" height="17" src="img/icons/${type || 'flight'}.png" alt="Event type icon">
          </label>
          <input class="event__type-toggle visually-hidden" id="event-type-toggle-1" type="checkbox">
          <div class="event__type-list">
            <fieldset class="event__type-group">
              <legend class="visually-hidden">Event type</legend>
              ${eventTypeOptions}
            </fieldset>
          </div>
        </div>

        <div class="event__field-group event__field-group--destination">
          <label class="event__label event__type-output" for="event-destination-1">${type || 'Flight'}</label>
          <input class="event__input event__input--destination" id="event-destination-1" type="text" name="event-destination" value="${destinationName || ''}" list="destination-list-1">
          <datalist id="destination-list-1">
            <option value="Valencia"></option><option value="Venice"></option>
            <option value="Madrid"></option><option value="Geneva"></option>
            <option value="Rome"></option><option value="Saint Petersburg"></option>
            <option value="Chamonix"></option><option value="Amsterdam"></option>
            <option value="Munich"></option><option value="Den Haag"></option>
          </datalist>
        </div>

        <div class="event__field-group event__field-group--time">
          <label class="visually-hidden" for="event-start-time-1">From</label>
          <input class="event__input event__input--time" id="event-start-time-1" type="text" name="event-start-time" value="${dateFrom ? formatDate(dateFrom, TIME_FORMATS.FULL_DATE) : ''}">
          &mdash;
          <label class="visually-hidden" for="event-end-time-1">To</label>
          <input class="event__input event__input--time" id="event-end-time-1" type="text" name="event-end-time" value="${dateTo ? formatDate(dateTo, TIME_FORMATS.FULL_DATE) : ''}">
        </div>

        <div class="event__field-group event__field-group--price">
          <label class="event__label" for="event-price-1">
            <span class="visually-hidden">Price</span>&euro;
          </label>
          <input class="event__input event__input--price" id="event-price-1" type="text" name="event-price" value="${basePrice ? he.encode(String(basePrice)) : '0'}" required>
        </div>

        <button class="event__save-btn btn btn--blue" type="submit" ${basePrice > 0 && dateFrom && dateTo && destinationName ? '' : 'disabled'}>Save</button>
        <button class="event__reset-btn" type="reset">Delete</button>
      </header>

      <section class="event__details">
        ${offerMarkup ? `<section class="event__section event__section--offers">
          <h3 class="event__section-title event__section-title--offers">Offers</h3>
          <div class="event__available-offers">${offerMarkup}</div>
        </section>` : ''}

        ${description ? `<section class="event__section event__section--destination">
          <h3 class="event__section-title event__section-title--destination">Destination</h3>
          <p class="event__destination-description">${description}</p>
          <div class="event__photos-container">
            <div class="event__photos-tape">${picturesMarkup}</div>
          </div>
        </section>` : ''}
      </section>
    </form>
  </li>`;
}

export default class FormCreationView extends AbstractStatefulView {
  #destinations = null;
  #offers = null;
  #onSubmit = null;
  #onDelete = null;
  #pickerFrom = null;
  #pickerTo = null;

  constructor({ allDestinations, allOffers, onFormSubmit, onDeleteClick }) {
    super();
    this.#destinations = allDestinations;
    this.#offers = allOffers;
    this.#onSubmit = onFormSubmit;
    this.#onDelete = onDeleteClick;

    this._setState({
      basePrice: 0,
      dateFrom: '',
      dateTo: '',
      destination: '',
      destinationName: '',
      destinationPictures: [],
      description: '',
      offers: [],
      type: '',
      isFavorite: false,
    });

    this._restoreHandlers();
  }

  get template() {
    return buildCreationTemplate(this._state);
  }

  _restoreHandlers() {
    const form = this.element.querySelector('.event');
    form.addEventListener('submit', this.#handleFormSubmit);
    form.querySelector('.event__reset-btn').addEventListener('click', this.#handleDeleteClick);
    form.querySelector('.event__type-group').addEventListener('change', this.#handleTypeChange);
    form.querySelector('.event__input--destination').addEventListener('change', this.#handleDestinationChange);
    form.querySelector('.event__input--price').addEventListener('change', this.#handlePriceChange);

    this.#initDatepickers();
  }

  #handleTypeChange = (evt) => {
    evt.preventDefault();
    const newType = evt.target.value;
    const offerSet = this.#offers.find((item) => item.type === newType);

    this.updateElement({
      offers: offerSet?.offers || [],
      type: newType,
    });
  };

  #handleDestinationChange = (evt) => {
    evt.preventDefault();
    const name = evt.target.value;
    const destination = this.#destinations.find((d) => d.name === name);

    if (!destination) {
      evt.target.value = '';
      this.updateElement({
        destination: '',
        description: '',
      });
      return;
    }

    this.updateElement({
      destination: destination.id,
      destinationName: destination.name,
      destinationPictures: destination.pictures,
      description: destination.description,
    });
  };

  #handlePriceChange = (evt) => {
    evt.preventDefault();
    const value = parseFloat(evt.target.value);

    this.updateElement({
      basePrice: isNaN(value) ? 0 : value,
    });
  };

  #onStartDateChange = ([date]) => {
    this.updateElement({ dateFrom: date });
  };

  #onEndDateChange = ([date]) => {
    this.updateElement({ dateTo: date });
  };

  #initDatepickers() {
    this.#pickerFrom = flatpickr(
      this.element.querySelector('#event-start-time-1'),
      {
        dateFormat: 'd/m/y H:i',
        enableTime: true,
        time24Hr: true,
        defaultDate: this._state.dateFrom,
        onChange: this.#onStartDateChange,
        maxDate: this._state.dateTo,
      }
    );

    this.#pickerTo = flatpickr(
      this.element.querySelector('#event-end-time-1'),
      {
        dateFormat: 'd/m/y H:i',
        enableTime: true,
        time24hr: true,
        defaultDate: this._state.dateTo,
        onChange: this.#onEndDateChange,
        minDate: this._state.dateFrom,
      }
    );
  }

  #handleFormSubmit = (evt) => {
    evt.preventDefault();
    this.#onSubmit(FormCreationView.toPoint(this._state));
  };

  #handleDeleteClick = (evt) => {
    evt.preventDefault();
    this.#onDelete(FormCreationView.toPoint(this._state));
  };

  static toPoint(state) {
    const point = { ...state };

    if (!point.description && !point.destinationName && !point.destinationPictures) {
      point.description = null;
      point.destinationName = null;
      point.destinationPictures = null;
    }

    delete point.description;
    delete point.destinationName;
    delete point.destinationPictures;

    return point;
  }
}
