import AbstractView from '../framework/view/abstract-view.js';
import { formatDate, formatDuration } from '../utils.js';
import { TIME_FORMATS } from '../const.js';
import he from 'he';

function createPointHTML(point, offerSet, destination) {
  const { basePrice, dateFrom, dateTo, type, isFavorite } = point;

  const selectedOffers = offerSet.offers
    .filter((offer) => point.offers.includes(offer.id))
    .map((offer) => `<li class="event__offer"><span class="event__offer-title">${offer.title}</span>
      &plus;&euro;&nbsp;<span class="event__offer-price">${offer.price}</span></li>`)
    .join('');

  return `
    <li class="trip-events__item">
      <div class="event">
        <time class="event__date" datetime="${formatDate(dateFrom, 'YYYY-MM-DD')}">
          ${formatDate(dateFrom, TIME_FORMATS.DAY)}
        </time>
        <div class="event__type">
          <img class="event__type-icon" width="42" height="42"
            src="img/icons/${type}.png" alt="Event type icon">
        </div>
        <h3 class="event__title">${type} ${destination.name}</h3>
        <div class="event__schedule">
          <p class="event__time">
            <time class="event__start-time" datetime="${formatDate(dateFrom, 'YYYY-MM-DDTHH:mm')}">
              ${formatDate(dateFrom, TIME_FORMATS.TIME)}
            </time>
            &mdash;
            <time class="event__end-time" datetime="${formatDate(dateTo, 'YYYY-MM-DDTHH:mm')}">
              ${formatDate(dateTo, TIME_FORMATS.TIME)}
            </time>
          </p>
          <p class="event__duration">${formatDuration(dateFrom, dateTo)}</p>
        </div>
        <p class="event__price">
          &euro;&nbsp;<span class="event__price-value">${he.encode(String(basePrice))}</span>
        </p>
        <h4 class="visually-hidden">Offers:</h4>
        <ul class="event__selected-offers">${selectedOffers}</ul>
        <button class="event__favorite-btn ${isFavorite ? 'event__favorite-btn--active' : ''}" type="button">
          <span class="visually-hidden">Add to favorite</span>
          <svg class="event__favorite-icon" width="28" height="28" viewBox="0 0 28 28">
            <path d="M14 21l-8.11 4.27 1.54-9L0 9.26l9.05-1.32L14 0l4.95 7.94L28 9.26l-7.43 7.01 1.54 9z"/>
          </svg>
        </button>
        <button class="event__rollup-btn" type="button">
          <span class="visually-hidden">Open event</span>
        </button>
      </div>
    </li>`;
}

export default class PointView extends AbstractView {
  #point = null;
  #offer = null;
  #destination = null;
  #onEdit = null;
  #onFavorite = null;

  constructor({ point, offer, destination, onEditClick, onFavoriteClick }) {
    super();
    this.#point = point;
    this.#offer = offer;
    this.#destination = destination;
    this.#onEdit = onEditClick;
    this.#onFavorite = onFavoriteClick;

    this.element.querySelector('.event__rollup-btn').addEventListener('click', this.#onEditClick);
    this.element.querySelector('.event__favorite-btn').addEventListener('click', this.#onFavoriteClick);
  }

  get template() {
    return createPointHTML(this.#point, this.#offer, this.#destination);
  }

  #onEditClick = (evt) => {
    evt.preventDefault();
    this.#onEdit();
  };

  #onFavoriteClick = (evt) => {
    evt.preventDefault();
    this.#onFavorite();
  };

  shake() {
    this.element.style.animation = 'shake 0.6s';
    this.element.style.transformOrigin = 'center';

    setTimeout(() => {
      this.element.style.animation = '';
    }, 600);
  }
}
