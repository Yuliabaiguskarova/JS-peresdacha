const InsertPosition = {
  START_BEFORE: 'beforebegin',
  START_INSIDE: 'afterbegin',
  END_INSIDE: 'beforeend',
  END_AFTER: 'afterend',
};

function htmlToElement(markup) {
  const wrap = document.createElement('div');
  wrap.innerHTML = markup.trim();
  return wrap.firstElementChild;
}

function inject(component, target, position = InsertPosition.END_INSIDE) {
  target.insertAdjacentElement(position, component.getElement());
}

export { InsertPosition as RenderPosition, htmlToElement as createElement, inject as render };
