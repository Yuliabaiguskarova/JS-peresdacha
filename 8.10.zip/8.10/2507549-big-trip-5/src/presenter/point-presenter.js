import { render, replace, remove } from '../framework/render.js';
import PointView from '../view/route-point-element-view.js';
import FormEditView from '../view/form-editing-view.js';
import { MODE, USER_ACTION, UPDATE_TYPES } from '../const.js';

export default class PointPresenter {
  #point = null;
  #offers = [];
  #destination = null;
  #destinationsList = [];
  #offersList = [];
  #listContainer = null;

  #mode = MODE.DEFAULT;

  #cardComponent = null;
  #formComponent = null;

  #onModeChange = null;
  #onDataChange = null;

  constructor(destinations, offers, container, onModeChange, onDataChange) {
    this.#destinationsList = destinations;
    this.#offersList = offers;
    this.#listContainer = container;
    this.#onModeChange = onModeChange;
    this.#onDataChange = onDataChange;
  }

  init(point) {
    this.#point = point;
    this.#offers = this.#offersList.find((o) => o.type === point.type) ?? { offers: [], type: '' };
    this.#destination = this.#destinationsList.find((d) => d.id === point.destination);

    const previousCard = this.#cardComponent;
    const previousForm = this.#formComponent;

    this.#cardComponent = new PointView({
      point: this.#point,
      offer: this.#offers,
      destination: this.#destination,
      onEditClick: this.#switchToEdit,
      onFavoriteClick: this.#toggleFavorite,
    });

    this.#formComponent = new FormEditView({
      point: this.#point,
      offer: this.#offers,
      destination: this.#destination,
      allDestinations: this.#destinationsList,
      allOffers: this.#offersList,
      onRollupClick: this.#switchToView,
      onFormSubmit: (updated) => {
        this.#onDataChange(USER_ACTION.UPDATE_POINT, UPDATE_TYPES.PATCH, { ...updated });
        this.#switchToView();
      },
      onDeleteClick: (target) => {
        this.#onDataChange(USER_ACTION.DELETE_POINT, UPDATE_TYPES.MINOR, { ...target });
      },
    });

    if (previousCard === null || previousForm === null) {
      render(this.#cardComponent, this.#listContainer);
      return;
    }

    if (this.#mode === MODE.DEFAULT) {
      replace(this.#cardComponent, previousCard);
    } else if (this.#mode === MODE.EDITING) {
      replace(this.#formComponent, previousForm);
    }

    remove(previousCard);
    remove(previousForm);
  }

  destroy() {
    remove(this.#cardComponent);
    remove(this.#formComponent);
  }

  resetView() {
    if (this.#mode !== MODE.DEFAULT) {
      this.#switchToView();
    }
  }

  setSaving() {
    if (this.#mode === MODE.EDITING) {
      this.#formComponent.updateElement({
        isDisabled: true,
        isSaving: true,
      });
    }
  }

  setDeleting() {
    if (this.#mode === MODE.EDITING) {
      this.#formComponent.updateElement({
        isDisabled: true,
        isDeleting: true,
      });
    }
  }

  setAborting() {
    if (this.#mode === MODE.DEFAULT) {
      this.#cardComponent.shake();
    } else {
      this.#formComponent.shake(() => {
        this.#formComponent.updateElement({
          isDisabled: false,
          isSaving: false,
          isDeleting: false,
        });
      });
    }
  }

  #switchToEdit = () => {
    replace(this.#formComponent, this.#cardComponent);
    document.addEventListener('keydown', this.#onEscape);
    this.#onModeChange();
    this.#mode = MODE.EDITING;
  };

  #switchToView = () => {
    replace(this.#cardComponent, this.#formComponent);
    document.removeEventListener('keydown', this.#onEscape);
    this.#mode = MODE.DEFAULT;
  };

  #toggleFavorite = () => {
    this.#onDataChange(USER_ACTION.UPDATE_POINT, UPDATE_TYPES.PATCH, {
      ...this.#point,
      isFavorite: !this.#point.isFavorite,
    });
  };

  #onEscape = (evt) => {
    if (evt.key === 'Escape') {
      evt.preventDefault();
      this.#formComponent.reset();
      this.#switchToView();
    }
  };
}
