import { render, replace, remove } from '../framework/render.js';
import { FILTER_TYPES, FILTERS, UPDATE_TYPES } from '../const.js';
import FiltersView from '../view/filters-view.js';

export default class FilterController {
  #container = null;
  #filtersModel = null;
  #pointsModel = null;
  #view = null;

  constructor({ filterModel, pointsModel }) {
    this.#container = document.querySelector('.trip-controls__filters');
    this.#filtersModel = filterModel;
    this.#pointsModel = pointsModel;

    this.#pointsModel.addObserver(this.#handleModelChange);
    this.#filtersModel.addObserver(this.#handleModelChange);
  }

  get availableFilters() {
    const allPoints = this.#pointsModel.getPoints();
    return Object.values(FILTER_TYPES).map((type) => ({
      type,
      points: FILTERS[type](allPoints),
    }));
  }

  init() {
    const filters = this.availableFilters;
    const previous = this.#view;

    this.#view = new FiltersView({
      filters,
      onFilterTypeChange: this.#onFilterChange,
    });

    if (previous === null) {
      render(this.#view, this.#container);
    } else {
      replace(this.#view, previous);
      remove(previous);
    }
  }

  dispose() {
    remove(this.#view);
  }

  #onFilterChange = (type) => {
    if (this.#filtersModel.filter === type) {
      return;
    }

    this.#filtersModel.updateFilter(UPDATE_TYPES.MAJOR, type);
  };

  #handleModelChange = () => {
    this.init();
  };
}
