import { render, remove, RenderPosition } from '../framework/render.js';
import { USER_ACTION, UPDATE_TYPES } from '../const.js';
import { nanoid } from 'nanoid';
import FormCreationView from '../view/form-creation-view.js';

export default class NewPointCreator {
  #destinations = [];
  #offers = [];
  #container = null;
  #onSubmit = null;
  #formComponent = null;
  #addBtn = null;

  constructor(destinationsList, offersList, listContainer, onSubmitCallback) {
    this.#destinations = destinationsList;
    this.#offers = offersList;
    this.#container = listContainer;
    this.#onSubmit = onSubmitCallback;
    this.#addBtn = document.querySelector('.trip-main__event-add-btn');
  }

  init() {
    if (this.#formComponent !== null) {
      return;
    }

    this.#formComponent = new FormCreationView({
      allDestinations: this.#destinations,
      allOffers: this.#offers,
      onFormSubmit: (pointData) => {
        this.#onSubmit(USER_ACTION.ADD_POINT, UPDATE_TYPES.MINOR, { id: nanoid(), ...pointData });
        this.#enableAddButton();
      },
      onDeleteClick: () => {
        this.destroy();
        this.#enableAddButton();
      },
    });

    render(this.#formComponent, this.#container, RenderPosition.AFTERBEGIN);
    document.addEventListener('keydown', this.#handleEscape);
  }

  destroy() {
    if (this.#formComponent === null) {
      return;
    }

    remove(this.#formComponent);
    this.#formComponent = null;

    document.removeEventListener('keydown', this.#handleEscape);
  }

  #enableAddButton() {
    if (this.#addBtn) {
      this.#addBtn.disabled = false;
    }
  }

  #handleEscape = (evt) => {
    if (evt.key === 'Escape') {
      evt.preventDefault();
      this.destroy();
      this.#enableAddButton();
    }
  };
}
