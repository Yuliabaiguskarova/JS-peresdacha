import { render, remove } from '../framework/render.js';
import {
  sortByDay,
  sortByDuration,
  sortByPrice
} from '../utils.js';
import {
  SORT_TYPES,
  UPDATE_TYPES,
  USER_ACTION,
  FILTERS,
  FILTER_TYPES,
  TIME_LIMIT
} from '../const.js';
import UiBlocker from '../framework/ui-blocker/ui-blocker.js';
import SortView from '../view/sorting-view.js';
import PointListView from '../view/route-point-list-view.js';
import EmptyView from '../view/empty-task-list-view.js';
import LoaderView from '../view/loading-view.js';
import FiltersModel from '../model/filters-model.js';
import PointController from './point-presenter.js';
import FilterController from './filter-presenter.js';
import CreatePointController from './new-point-presenter.js';

export default class MainPresenter {
  #container = null;
  #pointsModel = null;
  #filtersModel = null;
  #filterType = FILTER_TYPES.EVERYTHING;
  #sortType = SORT_TYPES[0];
  #uiBlocker = null;

  #sortView = null;
  #pointListView = new PointListView();
  #loaderView = new LoaderView();
  #filterPresenter = null;

  #isLoading = true;
  #pointControllers = new Map();

  constructor({ pointsModel }) {
    this.#container = document.querySelector('.trip-events');
    this.#pointsModel = pointsModel;
    this.#filtersModel = new FiltersModel();
    this.#uiBlocker = new UiBlocker({
      lowerLimit: TIME_LIMIT.LOWER_LIMIT,
      upperLimit: TIME_LIMIT.UPPER_LIMIT,
    });

    this.#pointsModel.addObserver(this.#onModelChange);
    this.#filtersModel.addObserver(this.#onModelChange);
  }

  startInit() {
    this.#renderBoard();
  }

  init() {
    this.#renderBoard();
  }

  createPoint() {
    this.#sortType = SORT_TYPES[0];
    this.#filtersModel.updateFilter(UPDATE_TYPES.MAJOR, FILTER_TYPES.EVERYTHING);
    this.#renderNewPointForm();
  }

  #renderBoard() {
    if (this.#isLoading) {
      render(this.#loaderView, this.#container);
      return;
    }

    const points = this.#getSortedAndFilteredPoints();

    if (points.length === 0) {
      render(new EmptyView(), this.#container);
      return;
    }

    this.#renderFilterBlock();
    this.#renderSort();
    render(this.#pointListView, this.#container);

    for (const point of points) {
      this.#renderSinglePoint(point);
    }
  }

  #renderFilterBlock() {
    this.#filterPresenter = new FilterController({
      filterModel: this.#filtersModel,
      pointsModel: this.#pointsModel,
    });
    this.#filterPresenter.init();
  }

  #renderSort() {
    this.#sortView = new SortView({
      sortType: this.#sortType,
      onSortTypeChange: this.#onSortChange,
    });
    render(this.#sortView, this.#container);
  }

  #renderSinglePoint(point) {
    const controller = new PointController(
      this.#pointsModel.getDestinations(),
      this.#pointsModel.getOffers(),
      this.#pointListView.element,
      this.#resetAll,
      this.#handlePointUpdate
    );
    controller.init(point);
    this.#pointControllers.set(point.id, controller);
  }

  #renderNewPointForm() {
    const creator = new CreatePointController(
      this.#pointsModel.getDestinations(),
      this.#pointsModel.getOffers(),
      this.#pointListView.element,
      this.#handlePointUpdate
    );
    creator.init();
  }

  #getSortedAndFilteredPoints() {
    this.#filterType = this.#filtersModel.filter;
    const all = this.#pointsModel.getPoints();
    const filtered = FILTERS[this.#filterType](all);

    switch (this.#sortType) {
      case SORT_TYPES[0]: return filtered.sort(sortByDay);
      case SORT_TYPES[2]: return filtered.sort(sortByDuration);
      case SORT_TYPES[3]: return filtered.sort(sortByPrice);
      default: return filtered;
    }
  }

  #resetAll = () => {
    this.#pointControllers.forEach((c) => c.resetView());
  };

  #handlePointUpdate = async (actionType, updateType, pointData) => {
    this.#uiBlocker.block();

    switch (actionType) {
      case USER_ACTION.UPDATE_POINT:
        this.#pointControllers.get(pointData.id).setSaving();
        try {
          await this.#pointsModel.updatePoint(updateType, pointData);
        } catch {
          this.#pointControllers.get(pointData.id).setAborting();
        }
        break;

      case USER_ACTION.ADD_POINT:
        this.#pointsModel.addPoint(updateType, pointData);
        break;

      case USER_ACTION.DELETE_POINT:
        this.#pointControllers.get(pointData.id).setDeleting();
        try {
          await this.#pointsModel.deletePoint(updateType, pointData);
        } catch {
          this.#pointControllers.get(pointData.id).setAborting();
        }
        break;
    }

    this.#uiBlocker.unblock();
  };

  #onSortChange = (selectedSort) => {
    if (this.#sortType === selectedSort) {
      return;
    }

    this.#sortType = selectedSort;
    this.#clearBoard();
    this.init();
  };

  #clearBoard() {
    this.#pointControllers.forEach((c) => c.destroy());
    this.#pointControllers.clear();

    remove(this.#sortView);
    remove(this.#loaderView);
    remove(this.#pointListView);

    if (this.#filterPresenter) {
      this.#filterPresenter.dispose();
    }
  }

  #onModelChange = (type, payload) => {
    switch (type) {
      case UPDATE_TYPES.PATCH:
        this.#pointControllers.get(payload.id).init(payload);
        break;
      case UPDATE_TYPES.MINOR:
        this.#clearBoard();
        this.init();
        break;
      case UPDATE_TYPES.MAJOR:
        this.#sortType = SORT_TYPES[0];
        this.#clearBoard();
        this.init();
        break;
      case UPDATE_TYPES.INIT:
        this.#isLoading = false;
        remove(this.#loaderView);
        this.init();
        break;
    }
  };
}
