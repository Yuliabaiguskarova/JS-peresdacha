import dayjs from 'dayjs';
import { TIME_SUFFIXES } from './const';

export const pickRandom = (arr) => {
  const index = Math.floor(Math.random() * arr.length);
  return arr[index];
};

export const randomInRange = (min, max) =>
  Math.round(Math.random() * (max - min) + min);


export const formatDate = (inputDate, desiredFormat) =>
  dayjs(inputDate).format(desiredFormat);


export const formatDuration = (start, end) => {
  const from = dayjs(start);
  const to = dayjs(end);
  const totalMinutes = to.diff(from, 'minute');

  const days = Math.floor(totalMinutes / 1440);
  const hours = Math.floor((totalMinutes % 1440) / 60);
  const minutes = (totalMinutes % 60) + 1;

  const segments = [days, hours, minutes];
  const output = [];

  segments.forEach((val, idx) => {
    if (val > 0) {
      const padded = val < 10 ? `0${val}` : val;
      output.push(`${padded}${TIME_SUFFIXES[idx]}`);
    }
  });

  return output.join(' ') || '00M';
};

export const isPointPresent = (point) => {
  const now = dayjs();
  const from = dayjs(point.dateFrom);
  const to = dayjs(point.dateTo);
  return (now.isAfter(from) || now.isSame(from)) &&
         (now.isBefore(to) || now.isSame(to));
};

export const isPointFuture = (point) => dayjs().isBefore(dayjs(point.dateFrom));

export const isPointPast = (point) => dayjs().isAfter(dayjs(point.dateTo));

export const sortByDay = (a, b) => new Date(a.dateFrom) - new Date(b.dateFrom);
export const sortByPrice = (a, b) => b.basePrice - a.basePrice;
export const sortByDuration = (a, b) =>
  dayjs(b.dateTo).diff(dayjs(b.dateFrom)) - dayjs(a.dateTo).diff(dayjs(a.dateFrom));
