import ApiService from '../framework/api-service.js';
import { METHOD } from '../const.js';

export default class PointsApiService extends ApiService {
  get points() {
    return this._load({ url: 'points' }).then(ApiService.parseResponse);
  }

  get destinations() {
    return this._load({ url: 'destinations' }).then(ApiService.parseResponse);
  }

  get offers() {
    return this._load({ url: 'offers' }).then(ApiService.parseResponse);
  }

  async updatePoint(point) {
    const response = await this._load({
      url: `points/${point.id}`,
      method: METHOD.PUT,
      body: JSON.stringify(this.#toServerFormat(point)),
      headers: new Headers({ 'Content-Type': 'application/json' }),
    });

    return await ApiService.parseResponse(response);
  }

  async addPoint(point) {
    const response = await this._load({
      url: 'points',
      method: METHOD.POST,
      body: JSON.stringify(this.#toServerFormat(point)),
      headers: new Headers({ 'Content-Type': 'application/json' }),
    });

    return await ApiService.parseResponse(response);
  }

  async deletePoint(point) {
    return this._load({
      url: `points/${point.id}`,
      method: METHOD.DELETE,
    });
  }

  #toServerFormat(point) {
    const adapted = {
      ...point,
      'date_from': point.dateFrom instanceof Date ? point.dateFrom.toISOString() : null,
      'date_to': point.dateTo instanceof Date ? point.dateTo.toISOString() : null,
      'base_price': Number(point.basePrice),
      'is_favorite': point.isFavorite,
    };

    delete adapted.dateFrom;
    delete adapted.dateTo;
    delete adapted.basePrice;
    delete adapted.isFavorite;

    return adapted;
  }
}
