import Observable from '../framework/observable.js';

export default class OffersModel extends Observable {
  #offersList = [];
  #apiService = null;

  constructor({ pointsApiService }) {
    super();
    this.#apiService = pointsApiService;
  }

  getAll() {
    return this.#offersList;
  }

  async init() {
    try {
      this.#offersList = await this.#apiService.offers;
    } catch {
      this.#offersList = [];
    }
  }
}
