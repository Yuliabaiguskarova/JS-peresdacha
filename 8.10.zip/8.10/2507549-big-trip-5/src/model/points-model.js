import Observable from '../framework/observable.js';
import { UPDATE_TYPES } from '../const.js';

export default class PointsModel extends Observable {
  #points = [];
  #offers = [];
  #destinations = [];
  #api = null;

  constructor({ pointsApiService }) {
    super();
    this.#api = pointsApiService;
  }

  async init() {
    try {
      const fetchedPoints = await this.#api.points;
      this.#points = fetchedPoints.map(this.#fromServerFormat);

      this.#offers = await this.#api.offers;
      this.#destinations = await this.#api.destinations;
    } catch {
      this.#points = [];
      this.#offers = [];
      this.#destinations = [];
    }

    this._notify(UPDATE_TYPES.INIT);
  }

  getPoints() {
    return this.#points;
  }

  getOffers() {
    return this.#offers;
  }

  getDestinations() {
    return this.#destinations;
  }

  async updatePoint(updateType, pointData) {
    const index = this.#points.findIndex((item) => item.id === pointData.id);
    if (index === -1) {
      throw new Error('No point found for update');
    }

    try {
      const updated = await this.#api.updatePoint(pointData);
      const normalized = this.#fromServerFormat(updated);

      this.#points.splice(index, 1, normalized);
      this._notify(updateType, normalized);
    } catch {
      throw new Error('Failed to update point');
    }
  }

  async addPoint(updateType, newPoint) {
    try {
      const added = await this.#api.addPoint(newPoint);
      const normalized = this.#fromServerFormat(added);

      this.#points.unshift(normalized);
      this._notify(updateType, normalized);
    } catch {
      throw new Error('Failed to add point');
    }
  }

  async deletePoint(updateType, point) {
    const index = this.#points.findIndex((item) => item.id === point.id);
    if (index === -1) {
      throw new Error('No point found for delete');
    }

    try {
      await this.#api.deletePoint(point);
      this.#points.splice(index, 1);
      this._notify(updateType, point);
    } catch {
      throw new Error('Failed to delete point');
    }
  }

  #fromServerFormat(serverPoint) {
    const adapted = {
      ...serverPoint,
      dateFrom: serverPoint['date_from'] ? new Date(serverPoint['date_from']) : null,
      dateTo: serverPoint['date_to'] ? new Date(serverPoint['date_to']) : null,
      basePrice: serverPoint['base_price'],
      isFavorite: serverPoint['is_favorite'],
    };

    delete adapted['date_from'];
    delete adapted['date_to'];
    delete adapted['base_price'];
    delete adapted['is_favorite'];

    return adapted;
  }
}
