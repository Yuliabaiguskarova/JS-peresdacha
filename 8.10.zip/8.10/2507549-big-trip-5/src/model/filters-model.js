import Observable from '../framework/observable.js';
import { FILTER_TYPES } from '../const.js';

export default class FiltersModel extends Observable {
  #currentFilter = FILTER_TYPES.EVERYTHING;

  get filter() {
    return this.#currentFilter;
  }

  updateFilter(type, newFilter) {
    this.#currentFilter = newFilter;
    this._notify(type, newFilter);
  }
}
