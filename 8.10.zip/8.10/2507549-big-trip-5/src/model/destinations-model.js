import Observable from '../framework/observable.js';

export default class DestinationsModel extends Observable {
  #destinationsList = [];
  #api = null;

  constructor({ pointsApiService }) {
    super();
    this.#api = pointsApiService;
  }

  getAll() {
    return this.#destinationsList;
  }

  async init() {
    try {
      this.#destinationsList = await this.#api.destinations;
    } catch {
      this.#destinationsList = [];
    }
  }
}
