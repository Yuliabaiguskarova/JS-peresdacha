import { AUTHORIZATION, END_POINT } from './const.js';
import Presenter from './presenter/main-presenter.js';
import PointsApiService from './model/points-api-service.js';
import PointsModel from './model/points-model.js';

const addPointBtn = document.querySelector('.trip-main__event-add-btn');

const model = new PointsModel({
  pointsApiService: new PointsApiService(END_POINT, AUTHORIZATION)
});
const presenter = new Presenter({ pointsModel: model });

const handleAddBtnClick = (event) => {
  event.preventDefault();
  presenter.createPoint();
  addPointBtn.disabled = true;
};

addPointBtn.addEventListener('click', handleAddBtnClick);

presenter.startInit();
model.init().finally();
